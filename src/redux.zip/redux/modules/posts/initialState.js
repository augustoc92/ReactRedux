// initialState:
const initialState = {
  defaultList: [],
  isFetching: false,
  errorMsg: ''
}

export default initialState
